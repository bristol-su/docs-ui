'use strict'

module.exports = (name) => {
  return name.substring(0, 21) === 'api-client-php-module'
}
