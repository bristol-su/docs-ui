'use strict'

module.exports = (name) => {
  return name.substring(0, 6) === 'module'
}
