'use strict'

module.exports = (name) => {
  return name.includes('playground') || name.includes('portal') || name.includes('control-frontend')
}
