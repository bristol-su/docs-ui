'use strict'

module.exports = (name) => {
  return name.substring(0, 11) === 'integration'
}
