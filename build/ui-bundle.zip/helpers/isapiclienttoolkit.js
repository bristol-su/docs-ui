'use strict'

module.exports = (name) => {
  return name === 'api-client-php-toolkit'
}
